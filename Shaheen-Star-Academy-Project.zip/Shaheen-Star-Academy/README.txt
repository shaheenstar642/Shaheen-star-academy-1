Shaheen Star Academy - Website Project

Folder structure:
- index.html              Main academy website + portal UI
- js/supabase-config.js   Placeholder for the online database connection
- css/                    Reserved for future external styles
- assets/                 Reserved for future images/files

IMPORTANT:
The current index.html stores portal data in browser localStorage. The Supabase URL/key are intentionally not inserted yet. Once the Supabase project URL and anon/public key are provided, the database layer can be connected.
