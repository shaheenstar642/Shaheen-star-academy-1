// Supabase connection placeholder.
// Database URL and anon key will be added when provided.
const SUPABASE_CONFIG = {
  url: '',
  anonKey: ''
};
